package com.mxgraph.io.gliffy.model;

public class Metadata
{

	private String title;

	public Metadata()
	{
		super();
	}

	public String getTitle()
	{
		return title;
	}

	public void setTitle(String title)
	{
		this.title = title;
	}

}
