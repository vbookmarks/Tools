package com.mxgraph.export;

public class mxPdfCanvas implements mxICanvas2
{
	public void scale(double value)
	{

	}

	public void translate(double dx, double dy)
	{

	}

	public void save()
	{

	}

	public void restore()
	{

	}

	public Object setDrawingHint(Object key, Object hint)
	{
		return null;
	}

	public void setDashed(boolean value)
	{

	}

	public void setFontSize(float value)
	{

	}

	public void setFontFamily(Object value)
	{

	}

	public void setFontStyle(int value)
	{

	}

	public void setStrokeWidth(double value)
	{

	}

	public void setStrokeColor(Object value)
	{

	}

	public void setFontColor(Object value)
	{

	}

	public void setFillColor(Object value)
	{

	}

	public void setGradient(Object color1, Object color2, double x, double y,
			double w, double h, Object direction)
	{

	}

	public void setGlassGradient(double x, double y, double w, double h)
	{

	}

	public void setAlpha(double value)
	{

	}

	public void image(double x, double y, double w, double h, String src,
			boolean aspect, boolean flipH, boolean flipV)
	{

	}

	public void rect(double x, double y, double w, double h)
	{

	}

	public void roundrect(double x, double y, double w, double h, double dx,
			double dy)
	{

	}

	public void ellipse(double x, double y, double w, double h)
	{

	}

	public void begin()
	{

	}

	public void moveTo(double x, double y)
	{

	}

	public void lineTo(double x, double y)
	{

	}

	public void quadTo(double x1, double y1, double x2, double y2)
	{

	}

	public void curveTo(double x1, double y1, double x2, double y2, double x3,
			double y3)
	{

	}

	public void end()
	{

	}

	public void close()
	{

	}

	public void fill()
	{

	}

	public void stroke()
	{

	}

	public void clip()
	{

	}

	public void fillAndStroke()
	{

	}

	public void shadow(Object value)
	{

	}

	public void text(double x, double y, double w, double h, String str,
			Object align, Object valign, boolean vertical)
	{

	}

}
