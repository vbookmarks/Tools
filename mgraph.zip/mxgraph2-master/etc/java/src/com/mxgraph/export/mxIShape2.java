package com.mxgraph.export;

import com.mxgraph.view.mxCellState;

public interface mxIShape2
{
	void paint(mxICanvas2 canvas, mxCellState state);
}
