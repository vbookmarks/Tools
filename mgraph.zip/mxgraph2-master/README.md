# mxgraph2

This is the development repo of mxGraph. Submit PRs and issues here. The release repo is https://github.com/jgraph/mxgraph (don't ask to change repo names, it's too complex, now).
