WinMerge/Filters/readme.txt

Filters holds the WinMerge runtime file filters.

These allow the user to only diff certain types of files, or to exclude
certain types of files from directory diffs.

These filters are distributed in the Filters
subdirectory beneath the WinMerge executables.
