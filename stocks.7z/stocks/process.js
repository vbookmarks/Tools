//step 1 = buy with total cash, with first price
//step 2 = At 10% of initial price, you set a stopLoss of 5%
//step 3 = execute stopLoss if price <= stopLoss price or update with new value
//step 4 = take out profit, wait for 22 days, invest original amount, repeat from step 1

(function () {
  let step = 1;
  const totalCash = 100000;
  let cashLeft = totalCash;
  let invested = 0;
  let investedAtPrice = 0;
  let stopLossAt = 0;
  let numberOfShares = 0;
  let profit = 0;
  let currentIndex = -1;
  let indexAfter1M = -1;

  const check = (day, index) => {
    //log(day.Date)
    currentIndex = index;

    switch (step) {
      case 1: {
        investedAtPrice = day.Close;
        buy(day);
        step = 2;
        break;
      }
      case 2: {
        const price = day.Close;
        updateInvestedAmt(price);
        const priceUpper = investedAtPrice + percentOf(investedAtPrice, 5);
        if (price >= priceUpper) {
          const priceLower = price - percentOf(price, 1);
          setStopLoss(day, priceLower);
          step = 3;
        }
        break;
      }
      case 3: {
        const price = day.Close;
        if (price <= stopLossAt) {
          runStopLoss(day);
          indexAfter1M = index + 15;
          step = 4;
        } else {
          const priceLower = price - percentOf(price, 1);
          if(priceLower > stopLossAt)
            setStopLoss(day, priceLower);
        }
        break;
      }
      case 4: {
        if (currentIndex >= indexAfter1M) step = 1;
        break;
      }
    }
  };

  const percentOf = (price, percent) => {
    return (price * percent) / 100;
  };

  const updateInvestedAmt = (price) => {
    invested = numberOfShares * price;
  };

  const buy = (day) => {
    const price = day.Close;
    numberOfShares = Math.round(cashLeft / price) - 1;
    updateInvestedAmt(price);
    cashLeft = cashLeft - invested;
    log(
      `buy => Date: ${day.Date} Price: ${price}  Invested: ${invested} Cash Left: ${cashLeft} stopLossAt: ${stopLossAt} numberOfShares: ${numberOfShares} Profit: ${profit}`
    );
  };

  const setStopLoss = (day, _stopLossAt) => {
    const price = day.Close;
    stopLossAt = _stopLossAt;
    log(
      `setStopLoss => Date: ${day.Date} Price: ${price}  Invested: ${invested} Cash Left: ${cashLeft} stopLossAt: ${stopLossAt} numberOfShares: ${numberOfShares} Profit: ${profit}`
    );
  };

  const runStopLoss = (day) => {
    const price = day.Close;
    updateInvestedAmt(price);
    profit = profit + (invested - totalCash);
    invested = 0;
    numberOfShares = 0;
    cashLeft = cashLeft = totalCash;
    log(
      `runStopLoss => Date: ${day.Date} Price: ${price}  Invested: ${invested} Cash Left: ${cashLeft} stopLossAt: ${stopLossAt} numberOfShares: ${numberOfShares} Profit: ${profit}`
    );
  };

  const log = (msg) => {
    console.log(msg);
  };

  data.map((day, i) => check(day, i));

  log(
    `FINAL => Invested: ${invested} Cash Left: ${cashLeft} numberOfShares: ${numberOfShares} Profit: ${profit}`
  );
})();
