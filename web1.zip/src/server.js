// load the things we need
var firebaseFunctions = require('firebase-functions');
var firebaseAdmin = require('firebase-admin');
var express = require('express');
var app = express();
var path = require('path');
var bodyParser = require('body-parser');
var port = process.env.PORT || 8080;

var _apiRouter = require('./router/_apiRouter');
var _uiRouter = require('./router/_uiRouter');

firebaseAdmin.initializeApp();

// set the view engine to ejs
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '/ui'));
app.use(express.static(path.join(__dirname, '/ui')));
app.use('/',_uiRouter);

app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json({ limit: '50mb' }));
app.use('/api', _apiRouter);

app.listen(port);
console.log('Listening at port: ' + port);

function keepAlive() {
    var http = require("http");
    setInterval(function () {
        http.get("http://www.jsongrid.com");
    }, 60000); // every 1 minutes (60000)
}

keepAlive();

exports.app = firebaseFunctions.https.onRequest(app);