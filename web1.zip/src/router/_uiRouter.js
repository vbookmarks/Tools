var express = require('express');
var uiRouter = express.Router();
var utils = require('../api/_utils.js');
var base = '../ui/ejs/';

uiRouter.route('/features').get(function (req, res) {
    res.render(base + 'features/features');
});

uiRouter.get('/json-(grid|formatter|validator|viewer|parser)', function (req, res) {
    var params = getParams(req);
    res.render(base + 'home/home', params);
});

uiRouter.route('/').get(function (req, res) {
    var params = getParams(req);

    res.render(base + 'home/home', params);
});

function getParams(req) {
    var _theme = 'D'; var _view = 'S';

    if (utils.getCookie(req, 'theme')) _theme = utils.getCookie(req, 'theme');
    if (utils.getCookie(req, 'view')) _view = utils.getCookie(req, 'view');

    var _keyword = extractKeyword(req.url);
    var _keywordContent = getKeywordContent(_keyword);
    return {
        theme: _theme,
        view: _view,
        keywordcontent: _keywordContent,
        keyword: _keyword,
        sitecontent: getSiteContent()
    };
}

function getKeywordContent(keyword) {
    var _siteContent = getSiteContent();

    var _keywordContent = _siteContent.filter(function (e) { return e.keyword == keyword; })[0];

    return _keywordContent;
}

function extractKeyword(url) {
    var path = url.substring(1, url.length);
    var keyword = path.split('?')[0];
    //keyword = keyword == '' ? 'root' : keyword;
    return keyword;
}

module.exports = uiRouter;

function getSiteContent() {
    var _siteContent = [
        {
            "keyword": "",
            "title": "JsonGrid - All-in-One Json Solutions Online - 2019",
            "h1Text": "JsonGrid - All-in-One Json Solutions Online - 2019",
            "h2Text": "We make Json easy for you!",
            "linkDesc": "All-in-One",
            "detail": []
        },
        {
            "keyword": "json-grid",
            "title": "Best Json Grid Viewer Online - 2019",
            "h1Text": "Json Grid",
            "h2Text": "Explore Json differently. One and only Json Grid Viewer!",
            "linkDesc": "Json Grid",
            "detail": [
                {
                    "header": "What is Json Grid",
                    "text": "Json Grid converts Json to table format, which provide luxury to view complex Json data into friendly table format."
                },
                {
                    "header": "How to use Json Grid",
                    "text": "Click on <img src='images/play.PNG'> icon to view Json in Grid Viewer. Click on <img src='images/plus.PNG'> icon to expand the table content as you go forward. Use <img src='images/expand_all.PNG'> button to expand entire Json Tree."
                },
                {
                    "header": "How does viewing Json in Grid help",
                    "text": "Json data is often very complex and have large number of object arrays. Json Grid Viewer converts these array of object into friendly table format."
                },
                {
                    "header": "What is GridSync feature",
                    "text": "When user clicks on any of the Grid element, say table cell, column or row, the left Json panel navigates to the associated Json field, providing instant preview of actual data."
                },
                {
                    "header": "How to convert Json to CSV",
                    "text": "While you are viewing array in table format, click on top-left <img src='images/table_menu.PNG'> icon. Click on 'Export To CSV', to generate CSV out of Json."
                },
                {
                    "header": "How can I edit Json using GridSync feature",
                    "text": "Json Panel (Left Panel) navigates to actual Json data elements when you click on Grid Cell, Column header or row. Json Panel is full Json Editor which can be used to edit Json."
                },
                {
                    "header": "Switch Theme, Switch View",
                    "text": "Click on <img src='images/settings.PNG'> on top-right corner of the web-page, and change theme you are comfortable with, Dark or Lite. Same way change View to Split or Tab View."
                },
                {
                    "header": "What is Json",
                    "text": "JSON is a lightweight data-interchange format. It is easy for machines to parse and generate. It is heavily used in software programs."
                },
                {
                    "header": "Free Json Grid Viewer",
                    "text": "Json Grid View is 100% free. It works cross platform. Enjoy this awesome tool. Learn more about Json."
                }
            ]
        },
        {
            "keyword": "json-formatter",
            "title": "Best Json Formatter Online - 2019",
            "h1Text": "Json Formatter",
            "h2Text": "Format Json instantly. Simply fast and easy!",
            "linkDesc": "Json Formatter",
            "detail": [
                {
                    "header": "What is Json Formatter?",
                    "text": "Json Formatter formats Json instantly (in left panel). It adds extra lines and spaces, so it human readable and inspectable. Also, it allows Json to view in nice table format (in right panel)."
                },
                {
                    "header": "How to format Json?",
                    "text": "Click <img src='images/format.PNG'> button to format the Json. The tool will format the Json only if the Json is valid. It's super easy and blazing fast."
                },
                {
                    "header": "Why does Json need formatting?",
                    "text": "Often Software developers need to inspect Json data that is floating around various apps. Often this data is difficult to read because of it's massive size. The tool makes it easy to read."
                },
                {
                    "header": "GridSync to connect Json to Grid",
                    "text": "GridSync is premium and unique feature of JsonGrid. On selecting Grid cell, column or row, the Json Editor (left panel) jumps to the specific Json item that is associated with."
                },
                {
                    "header": "Tool converts Json to CSV too",
                    "text": "If you need to see Json data in CSV format, this is right tool. Go to any table in Grid Viewer, click on <img src='images/table_menu.PNG'>."
                },
                {
                    "header": "Use as Json Editor with GridSync feature",
                    "text": "Using GridSync feature, user can quickly navigate to Json Item that is selected in Grid, which allows to edit right away."
                },
                {
                    "header": "Change Theme, Change View",
                    "text": "Choose Lite them to see background in white Or Dark theme to see in black. Both are developer friendly. Likewise, Choose Split View to see Json and Grid in one place. Choose Tab View to see Json or Grid one at a time and navigate between two on clicking on bottom tabs."
                },
                {
                    "header": "Describe Json",
                    "text": "JSON(JavaScript Object Notation) is a open data format to represent data elements. It's light in size and network friendly to interchange. To more about Json go to: <a href='https://www.json.org/'>Json.org</a> <a href='https://en.wikipedia.org/wiki/JSON'>Wikipedia</a>"
                },
                {
                    "header": "100% Free Json Formatter",
                    "text": "Json Formatter is completely free software. It works on web browser, so compatible with any operation system. It's simple and easy to use, Cheers!"
                }
            ]
        },
        {
            "keyword": "json-validator",
            "title": "Best Json Validator Online - 2019",
            "h1Text": "Json Validator",
            "h2Text": "Validate your Json, find all errors and fix right-away!",
            "linkDesc": "Json Validator",
            "detail": [
                {
                    "header": "What is Json Validator",
                    "text": "Json Validator is an online tool to validate Json data format. This tool enables user to not only validates the Json but also directs to the errors in Json. It allows use to fix them right away."
                },
                {
                    "header": "How to validate Json",
                    "text": "Find <img src='images/validate.PNG'> button, click it, tool will start validating your Json and show result in a moment. In case, Json is invalid, see errors in bottom status bar in Json Editor (left panel)."
                },
                {
                    "header": "Why does Json need be validated?",
                    "text": "Json is amazing format to hold and interchange data. But at times, Json could get very complex to handle, especially while editing Json elements. It's high likely that one will run into multiple errors while editing large Json data. This tool will show all errors with exact line numbers and associate error with correct suggestion to fix that right away. It's simply awesome tool!"
                },
                {
                    "header": "Grid and Json are connected, GridSync feature",
                    "text": "The Grid is generated out of Json data and tool hold a deep link to every single element of Json data. By click one of Grid's element, you will be navigated to linked Json Items."
                },
                {
                    "header": "Download CSV from Json",
                    "text": "The tool converts every Json Array into table. Right from icon in menu item <img src='images/table_menu.PNG'>, you will be able to download CSV file."
                },
                {
                    "header": "Modify Json whenever you want",
                    "text": "Use GridSync feature to find the right Json Element and edit the Json in left panel, simple and easy."
                },
                {
                    "header": "Modify Theme, light or dark background. Modify View, see larger one view",
                    "text": "Don't like too much background light, go to <img src='images/settings.PNG'> change the theme to Dark. Does Split view offer very little space, Change the view to Tab View."
                },
                {
                    "header": "Don't know about Json, teach me!",
                    "text": "Json is most popular data format that has been used to transfer data between programs and computers. To get details, please visit: <a href='https://www.json.org/'>Json.org</a> <a href='https://en.wikipedia.org/wiki/JSON'>Wikipedia</a>"
                },
                {
                    "header": "Totally free Json Validator",
                    "text": "This is free online tool to validate the Json, don't worry use as much as you want! It's cross platform and accessible in every browser and OS!"
                }
            ]
        },
        {
            "keyword": "json-viewer",
            "title": "Best Json Viewer Online - 2019",
            "h1Text": "Json Viewer",
            "h2Text": "Convert Json to table format. Amazing Json Viewer!",
            "linkDesc": "Json Viewer",
            "detail": [
                {
                    "header": "What is Json Viewer",
                    "text": "Json Viewer is ultimate tool to view complex Json data in nicely formatted table format, which enable developers to see complex data comfortably, ultimately improving productivity."
                },
                {
                    "header": "How to View Json in this tool",
                    "text": "Drop your Json data in left panel, Click <img src='images/play.PNG'> button, wait for tool to process through and generate Grid for you, that can be seen in right panel."
                },
                {
                    "header": "How does this tool in help in viewing Json",
                    "text": "The tool converts long arrays into table format which makes it easy for developers to look into large Json data."
                },
                {
                    "header": "Click Grid cells and see the magic in Json Panel, GridSync feature",
                    "text": "The Grid elements are tightly coupled with original Json Elements. To get a glimpse of this, try clicking on one of elements of Grid and see how Json Editor (left panel) navigates to actual Json data."
                },
                {
                    "header": "Export Json to CSV",
                    "text": "Do you need to share Json data with people who are not developers, use this tool to first generate Grid out of Json. Navigate to top corner on any table, click on menu item <img src='images/table_menu.PNG'>, and select option to export CSV from Json."
                },
                {
                    "header": "Use GridSync to change Json items",
                    "text": "Editing Json can be really cumbersome task, especially when it's complex. Utilizing GridSync feature in the tool, it could become piece of cake. Just click on Grid items, and modify Json values in the left panel."
                },
                {
                    "header": "Theme and View of your choice",
                    "text": "Every developer has his own choice on colors, especially they like Dark or Light editors. Using <img src='images/settings.PNG'> you can change this anytime. Similarly, If you need to see both view in large space, change view to Split View."
                },
                {
                    "header": "Can you give more details on Json data structure?",
                    "text": "Software use Json data structure to interchange data, since easy to read and can hold really complex data. Check out detailed information on Json here: <a href='https://www.json.org/'>Json.org</a> <a href='https://en.wikipedia.org/wiki/JSON'>Wikipedia</a>"
                },
                {
                    "header": "Fully free Json Viewer",
                    "text": "Json Viewer is completely free and cross-platform. Use it anywhere, everywhere!"
                }
            ]
        },
        {
            "keyword": "json-parser",
            "title": "Best Json Parser Online - 2019",
            "h1Text": "Json Parser",
            "h2Text": "Parse Json, view in tree and grid format!",
            "linkDesc": "Json Parser",
            "detail": [
                {
                    "header": "What is Json Parser",
                    "text": "Json Parser is the online tool to parse Json. Json could be very complex sometimes. If it's not formatted, it's really hard to understand the entire tree structure of it. This tool helps to parse this complex Json and shows in human friendly table format."
                },
                {
                    "header": "How to Parse Json using the tool",
                    "text": "After pasting your Json to Json Editor (left panel), click on <img src='images/play.PNG'> icon to parse the Json and view in Grid format."
                },
                {
                    "header": "How parsing Json helps to debug",
                    "text": "Parsing and Viewing Json in Grid helps developers to inspect and see complex structure of Json. That way it becomes easy to find issues in data structure overall."
                },
                {
                    "header": "Point actual Json elements while viewing Json in Grid, GridSync feature",
                    "text": "You can select Grid parts to see associated Json Elements in left panel. It's very fast, try it!"
                },
                {
                    "header": "Generate CSV out of Json anytime",
                    "text": "In case you need to generate CSV from Json, go to any table in Grid and click on top-left menu (img:table_menu), select export to CSV."
                },
                {
                    "header": "Update Json by using GridSync Feature",
                    "text": "If you need to edit Json, change any value,  use GridSync feature. Click anywhere on Grid to fly into Json, and change it."
                },
                {
                    "header": "Use dynamic Theme to see light or dark. Use tool in Split or Tab view",
                    "text": "Notice <img src='images/settings.PNG'> button in top-right corner, click and change your preference. If you prefer, change the view if you like to."
                },
                {
                    "header": "Enlighted on Json",
                    "text": "Json uses minimal characters to hold the large amount of data, which is the reason it's popular now a days. Get to know more from here: <a href='https://www.json.org/'>Json.org</a> <a href='https://en.wikipedia.org/wiki/JSON'>Wikipedia</a>"
                },
                {
                    "header": "Completely free Json Parser",
                    "text": "Json Parser is online tool, completely free and can be used from any browser."
                }
            ]
        }
    ];

    return _siteContent;
}