var express = require('express');
var apiRouter = express.Router();
var rawEditorFormat = require('../api/_rawGen.js');
var gridViewer = require('../api/_gridGen.js');
var CryptoJS = require("crypto-js");
var utils = require('../api/_utils.js');

apiRouter.route('/authentication/verify-auth-token').post(function (req, res) {
    try {
        var reqBody = req.body;
        var decryptedBody = JSON.parse(aesDecrypt('kymy9umth2ct3f3i', reqBody.authToken));

        dbInsert(req, decryptedBody);

        log('GetGT Started.');
        var formatRes = rawEditorFormat.formatMain(decryptedBody);
        var gridRes = gridViewer.GridHtml(decryptedBody);
        log('GetGT Ended.');
        var ret = { format: formatRes, grid: gridRes };
        var encrypedJson = JSON.parse('{"authToken": "' + aesEncrypt('idrc91e3s7rksi00', JSON.stringify(ret)) + '"}');
        res.send(encrypedJson);
    } catch (ex) {
        console.log(ex);
    }
});

function dbInsert(req, decryptedBody) {
    var _theme = 'DT'; var _view = 'DV'; var _guid = '';
    if (utils.getCookie(req, 'theme')) _theme = utils.getCookie(req, 'theme');
    if (utils.getCookie(req, 'view')) _view = utils.getCookie(req, 'view');
    if (utils.getCookie(req, 'guid')) _guid = utils.getCookie(req, 'guid');

    insertJsonToMlab(_theme, _view, _guid, decryptedBody);
}
function log(msg) {
    var d = new Date();
    console.log('[INFO: ' + d.toLocaleString() + '.' + d.getMilliseconds() + '] ' + msg);
}
function insertJsonToMlab(_theme, _view, _guid, _json) {
    try {
        var MongoClient = require('mongodb').MongoClient;
        var MONGO_URL = 'mongodb://Kaushal.papers:mlabmlab1@ds016068.mlab.com:16068/firsttest';
        var myobj = {
            DateTime: new Date(),
            Guid: _guid,
            Theme: _theme,
            View: _view,
            Json: _json
        };

        MongoClient.connect(MONGO_URL, function (err, db) {
            if (err) throw err;
            var dbo = db.db("firsttest");

            dbo.collection("Data").insertOne(myobj, function (err, res) {
                if (err) {
                    console.log('Error whilte inserting:' + err);
                }
                console.log("1 document inserted");
                db.close();
            });
        });
    } catch (ex) {
        console.log('Some error:' + ex);
    }
}

function aesEncrypt(secretKey, textToEncrypt) {
    var ciphertext = CryptoJS.AES.encrypt(textToEncrypt, secretKey);
    return ciphertext;
}
function aesDecrypt(secretKey, textToDecrypt) {
    var bytes = CryptoJS.AES.decrypt(textToDecrypt.toString(), secretKey);
    var plaintext = bytes.toString(CryptoJS.enc.Utf8);
    return plaintext;
}

module.exports = apiRouter;