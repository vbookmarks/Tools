function GridHtml(jsonIp) {
    function typeNiterate(obj, header, arrIndex, title, _gId) {
        if (typeCheck(obj) == "object") {
            var str = "";
            if (header.length == 0) {
                var arrTitle = title == null ? "" : "<div class='box'><span class='plusminus'>[+]</span><span class='title'>" + title + "&nbsp;{&nbsp;}</span>";
                var gId = _gId == '' ? getGId() : _gId;

                str = arrTitle + "<div class='tblcontainer'><table border='0' " + gId + " type='table' cellpadding='0' cellspacing='0' >";
                for (var key in obj) {
                    var keyGId = getGId();
                    var loopGId = getGId();
                    str += "<tr><td class='obj key name' type='cell' " + keyGId + "><span>" + key + "</span></td><td class='obj value' type='cell' " + loopGId + " >" + typeNiterate(obj[key], [], null, key, loopGId) + '</td></tr>';
                }
                str += "</table></div></div>";
            }
            else {
                str = "<tr><td class='obj order index' type='row' " + getGId() + " >" + arrIndex + "</td>";

                var i = 0;
                for (var key in header) {
                    var val = obj[header[key]];
                    if (val == null)
                        val = 'null';

                    var keyGId = getGId(true);
                    var gId = getGId();
                    str += "<td class='obj value' type='cell' " + keyGId + " " + gId + " >" + typeNiterate(val, [], null, header[key], gId) + '</td>';
                    i++;
                }
                str += "</tr>";
            }
            return str;
        }
        else if (typeCheck(obj) == "array") {
            var segments = [];
            var gId = _gId == '' ? getGId() : _gId;

            var arrTitle = title == null ? "" : "<div class='box'><span class='plusminus'>[+]</span><span class='title'>" + title + "&nbsp;[" + obj.length + "]</span><div class='tblcontainer'>";
            for (var i = 0; i < obj.length; i++) {
                var item = obj[i];
                var header = getHeader(item);
                var headerArr = getHeaderArr(item);

                var start = "<table border='0' cellpadding='0' cellspacing='0' type='table' " + gId + " >";
                var middle = "";
                if (header == "") {
                    var localGId = getGId();
                    middle = "<tr><td class='obj order index' type='row' " + localGId + " >" + (i + 1) + "</td><td type='cell' class='obj value' " + localGId + ">" + typeNiterate(item, [], null, null, localGId) + "</td></tr>";
                }
                else
                    middle = typeNiterate(item, headerArr, (i + 1), null, gId);

                var end = "</table>";

                segments.push({ 'start': start, 'header': header, 'headerArr': headerArr, 'middle': middle, 'end': end });
            }

            var str = arrTitle;
            for (var i = 0; i < segments.length; i++) {
                var seg = segments[i];

                if (i > 0 && seg.header == segments[i - 1].header) {
                    str = str.substring(0, str.length - 8);
                    str += seg.middle + seg.end;
                }
                else {
                    str += seg.start + seg.header + seg.middle + seg.end;
                }
            }
            str += "</div></div>";
            return str;
        }
        else {
            var _type = typeof obj;
            return "<span class='" + _type + "'>" + obj + "</span>";
        }
    }

    function typeCheck(obj) {

        if ((obj instanceof Object) && !(obj instanceof Array)) {
            return "object";
        }

        if ((obj instanceof Object) && (obj instanceof Array)) {
            return "array";
        }
    }

    function getHeader(obj) {
        var arrOfKeys = [];
        var str = "";
        if (typeCheck(obj) != "object") {
            return "";
        }

        for (var key in obj) {
            if (arrOfKeys.indexOf(key) === -1) {
                arrOfKeys.push(key);
            }
        }
        if (arrOfKeys.length > 0) {
            str += "<tr><th class='obj order' type='table'><div class='menu-container'><i class='glyphicon glyphicon-menu-hamburger' name='tblMenuOpener'></div></i></th>";
            for (var i = 0; i < arrOfKeys.length; i++) {
                str += "<th class='obj order name' type='column' ><span>" + arrOfKeys[i] + "</span></th>";
            }
            str += "</tr>";
        }
        return str;
    }

    function getHeaderArr(obj) {
        var arrOfKeys = [];
        if (typeCheck(obj) != "object") {
            return [];
        }

        for (var key in obj) {
            if (arrOfKeys.indexOf(key) === -1) {
                arrOfKeys.push(key);
            }
        }

        return arrOfKeys;
    }

    function getGId(isKey) {

        mainGId = mainGId + 1;
        var n = mainGId;

        return !isKey ? " gid='" + n + "' " : " kgid='" + n + "' ";
    }

    var mainGId = 0;

    return typeNiterate(jsonIp, [], null, null, '');
}

module.exports.GridHtml = GridHtml;