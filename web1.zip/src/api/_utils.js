function getCookie(req, key) {
    var _cookies = parseCookies(req);
    var sessionCookieValue = _cookies['__session'];
    var settings = sessionCookieValue == null ? {} : JSON.parse(unescape(sessionCookieValue));
    return settings[key];
}

function parseCookies(request) {
    var list = {},
        rc = request.headers.cookie;

    rc && rc.split(';').forEach(function (cookie) {
        var parts = cookie.split('=');
        list[parts.shift().trim()] = decodeURI(parts.join('='));
    });

    return list;
}


module.exports = {
    getCookie: getCookie
};