//var escapeHtml = require('escape-html');

function formatMain(rawJson) {

    function format(ip, isFirst, pad, isLastItem, _uid) {
        if (iso(ip)) {
            var start = '';
            var curPad = pad + 2;

            var uid = _uid == '' ? getUId() : _uid;
            if (len(ip) == 0) {
                var comma = isLastItem ? '' : ',';
                start = '{}' + comma;
            }

            else
                start = '{';
            ;
            if (isFirst) {
                var ln = getLineNo();
                fillArr(ln, [uid]);
                op += '<div id="ln_' + ln + '" ln="' + ln + '"><span ' + uid + '>' + start + '</span></div>';
            }
            else
                op = replace(op, '{val}', start);

            var i = 0;
            for (var key in ip) {
                var ln = getLineNo();
                var keyUId = getUId();
                var loopUId = getUId();
                fillArr(ln, [keyUId, loopUId]);
                op += '<div id="ln_' + ln + '" ln="' + ln + '">' + padStr(curPad) + '<span key ' + keyUId + '>"' + key + '"</span><span> : </span><span ' + loopUId + '>{val}</span></div>';
                var isLast = len(ip) == i + 1;
                format(ip[key], false, curPad, isLast, loopUId);
                i++;
            }

            curPad = curPad - 2;
            if (len(ip) != 0) {
                var comma = isLastItem ? '' : ',';
                var ln = getLineNo();
                fillArr(ln, [uid]);
                op += '<div  id="ln_' + ln + '" ln="' + ln + '">' + padStr(curPad) + '<span ' + uid + '>' + '}' + comma + '</span></div>';
            }

        }
        else if (isa(ip)) {
            var start = '';
            var curPad = pad + 2;
            var uid = _uid == '' ? getUId() : _uid;
            if (len(ip) == 0) {
                var comma = isLastItem ? '' : ',';
                start = '[]' + comma;
            }

            else
                start = '[';

            if (isFirst) {
                var ln = getLineNo();
                fillArr(ln, [uid]);
                op += '<div id="ln_' + ln + '" ln="' + ln + '"><span ' + uid + '>' + start + '</span></div>';
            }
            else
                op = replace(op, '{val}', start);

            var i = 0;
            for (var index in ip) {
                var ln = getLineNo();
                var loopUId = getUId();
                fillArr(ln, [loopUId]);
                op += '<div id="ln_' + ln + '" ln="' + ln + '">' + padStr(curPad) + '<span ' + loopUId + '>{val}</span></div>';
                var isLast = len(ip) == i + 1;
                format(ip[index], false, curPad, isLast, loopUId);
                i++;
            }

            curPad = curPad - 2;
            if (len(ip) != 0) {
                var ln = getLineNo();
                var comma = isLastItem ? '' : ',';
                fillArr(ln, [uid]);
                op += '<div id="ln_' + ln + '" ln="' + ln + '">' + padStr(curPad) + '<span ' + uid + '>' + ']' + comma + '</span></div>';
            }
        }
        else {
            var doubleQuote = '';
            if (typeof ip === 'string' || ip instanceof String) {
                doubleQuote = '"';
                // ip = fixCharIssue(ip);
                // ip = escapeHtml(ip);
            }

            var comma = isLastItem ? '' : ',';

            op = replace(op, '{val}', doubleQuote + ip + doubleQuote + comma);
        }

        fillArr(0, []);
    }

    function fixCharIssue(_text) {
        var arr = [
            { 'char': '\b', 'replaceWith': '\\b' },
            { 'char': '\f', 'replaceWith': '\\f' },
            { 'char': '\n', 'replaceWith': '\\n' },
            { 'char': '\r', 'replaceWith': '\\r' },
            { 'char': '\t', 'replaceWith': '\\t' },
            { 'char': '\v', 'replaceWith': '\\v' },
            { 'char': '\0', 'replaceWith': '\\0' },
            { 'char': '"', 'replaceWith': '\\"' }
        ];
        for (var i = 0; i < arr.length; i++) {
            _text = _text.split(arr[i].char).join(arr[i].replaceWith);
        }
        return _text;
    }

    function fillArr(ln, arrUIds) {
        if (op != '') {
            arr.push(op);
            op = '';
        }
        for (var i = 0; i < arrUIds.length; i++) {
            var u = parseInt(arrUIds[i].split(" uid='").join("").split("' ").join(""));
            mapping.push({
                't': getRndInteger(0, 200),
                'l': encrypt(ln, 7, 73),
                'g': getRndInteger(0, 200),
                'u': encrypt(u, 3, 23)
            }); // only l and u are imp
        }
    }

    function getRndInteger(min, max) {
        return Math.floor(Math.random() * (max - min)) + min;
    }

    function encrypt(number, multiply, add) {
        return ((number * multiply) + add);
    }

    function getLineNo() {
        lineNo = lineNo + 1;
        var n = lineNo;
        //$('div.lineNolist').append('<div class="lineno" ln="' + n + '">' + n + '</div>');
        //lineNoList += '<div class="lineno" ln="' + n + '">' + n + '</div>';
        return n;
    }

    function getUId() {
        mainUId = mainUId + 1;
        var n = mainUId;
        return " uid='" + n + "' ";
    }

    function replace(content, key, val) {
        //return content.split(key).join(val);
        //return content.replace(new RegExp(key, 'g'), val);
        var start = content.substring(0, content.length - 18); //18
        var end = content.substring(content.length - 13, content.length); //13
        var wholeLine = start + val + end;
        return wholeLine;
    }

    function padStr(num) {
        var p = '';
        for (var i = 0; i < num; i++) {
            if (i % 2) {
                p += '<span>&nbsp;&nbsp;</span>';
            }
            else {
                p += '<span class="pad-border">&nbsp;&nbsp;</span>';
            }

        }
        return p;
    }

    //returns length of object
    function len(val) {
        if (iso(val)) {
            return Object.keys(val).length
        }
        else if (isa(val)) {
            return val.length;
        }
        else {
            return val.length;
        }
    }

    function iso(val) {
        if ((val instanceof Object) && !(val instanceof Array)) {
            return true;
        }
        return false
    }

    function isa(val) {
        if ((val instanceof Object) && (val instanceof Array)) {
            return true;
        }
        return false;
    }

    function trimBoth(str) {
        return str.substring(0, 1).substring(0, str.length - 1);
    }

    var op = '';
    var lineNo = 0;
    var mainUId = 0;
    var lineNoList = '';
    var arr = [];
    var mapping = [];
    format(rawJson, true, 0, true, 0);
    var res = [];
    if (lineNo <= 40000)
        res = arr;
    return { formattedJson: [], l: lineNo, m: mapping };
}

module.exports.formatMain = formatMain;