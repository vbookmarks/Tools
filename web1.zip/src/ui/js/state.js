/* requires:
root.js
constants.js
utils.js
*/
(function () {
    function State() {

        function getSettings(name) {
            var retVal = null;

            if (name == $root.constants.Settings.THEME) {
                if (getCookie('theme'))
                    retVal = getCookie('theme');
                else
                    retVal = $root.constants.Theme.DARK;
            }
            else if (name == $root.constants.Settings.VIEW) {
                if (getCookie('view'))
                    retVal = getCookie('view');
                else
                    retVal = $root.constants.View.SPLIT;
            }

            return retVal;
        }

        function saveSettings(name, value) {
            if (name == $root.constants.Settings.THEME) {
                setCookie('theme', value);
            }
            else if (name == $root.constants.Settings.VIEW) {
                setCookie('view', value);
            }
        }

        function setCookie(key, val) {
            var sessionCookieValue = $.cookie('__session');
            var settings = sessionCookieValue == null ? {} : JSON.parse(sessionCookieValue);
            settings[key] = val;
            $.cookie('__session', JSON.stringify(settings), { expires: 365 });
        }

        function getCookie(key) {
            var sessionCookieValue = $.cookie('__session');
            var settings = sessionCookieValue == null ? {} : JSON.parse(sessionCookieValue);
            return settings[key];
        }

        function hasGuid() {
            return !(getCookie('guid') == null);
        }

        function createGuid(){
            var guid = uuidv4();
            setCookie('guid', guid);
        }

        function uuidv4() {
            return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
              var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
              return v.toString(16);
            });
          }
      
        this.saveSettings = saveSettings;
        this.getSettings = getSettings;
        this.hasGuid = hasGuid;
        this.createGuid = createGuid;
    }

    $root.state = new State();
})();