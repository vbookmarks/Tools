/* requires:
root.js
*/
(function () {
    function Constants() {

        var Settings = {
            THEME: 'T',
            VIEW: 'V'
        }

        var Theme = {
            DARK: 'D',
            LITE: 'L'
        };

        var View = {
            SPLIT: 'S',
            TAB: 'T'
        }

        //Public
        this.Theme = Theme;
        this.View = View;
        this.Settings = Settings;
    }

    $root.constants = new Constants();
})();