/* requires:
root.js
utils.js
toast.js
*/

(function () {
    function LazyLoader() {

        this.htmlContentLoad = function (content, $element) {

        }

        this.htmlLinesLoad = function (arrLines, $element, progressCallback) {
            Loadlines(arrLines, $element, progressCallback, 0);
        }

        function Loadlines(arrLines, $element, progressCallback, start) {
            var max = 2000;
            var _s = start;
            var _e = (_s + max) > arrLines.length ? arrLines.length : (_s + max);
            setTimeout(function (_start, _end) {
                var newArr = arrLines.slice(_start, _end);
                var joined = newArr.join('');
                $element.append(joined);
                // for (var j = _start; j < _end; j++) {
                //     $element.append(arrLines[j]);
                // }

                var percent = ((100 * _end) / arrLines.length).toFixed(0);

                if (progressCallback != null) progressCallback(percent);

                if (_end != arrLines.length) {
                    Loadlines(arrLines, $element, progressCallback, _end);
                }

            }, 1, _s, _e);
        }

        function LoadlinesWithoutTimeout(arrLines, $element, progressCallback, start) {
            var max = 200;
            var _start = start;
            var _end = (_start + max) > arrLines.length ? arrLines.length : (_start + max);
            for (var j = _start; j < _end; j++) {
                $element.append(arrLines[j]);
            }

            var percent = ((100 * _end) / arrLines.length).toFixed(0);
        
            if (progressCallback != null) progressCallback(percent);

            if (_end != arrLines.length) {
                Loadlines(arrLines, $element, progressCallback, _end);
            }
        }


        this.lazyPaste = function (content, $element, completeCalback) {
            var arr = chunkSubstr(content, 100000);
            $element.html('');
            for (var i = 0; i < arr.length; i++) {
                setTimeout(function (i) {
                    $element.append(arr[i]);
                    if (i == (arr.length - 1) && completeCalback != null) {
                        completeCalback();
                    }
                }, i + 10, i);
            }
        }

        this.delayExecute = function (ms) {
            return makeDelay(ms);
        }

        //Private Methods

        function chunkSubstr(str, size) {
            var numChunks = Math.ceil(str.length / size);
            var chunks = new Array(numChunks);

            for (var i = 0, o = 0; i < numChunks; ++i, o += size) {
                chunks[i] = str.substr(o, size);
            }

            return chunks;
        }

        function makeDelay(ms) {
            var timer = 0;
            return function (callback) {
                clearTimeout(timer);
                timer = setTimeout(callback, ms);
            };
        }
    }

    $root.lazyLoader = new LazyLoader();
})();