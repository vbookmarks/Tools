/* requires:
root.js
constants.js
utils.js
state.js
toast.js
lazyLoader.js
*/
(function () {
    function JsonEditor() {
        var editor = null;
        var btnClear = $('#btnClear');
        var btnMinify = $('#btnMinify');
        var btnSample = $('#btnSample');
        var btnValidate = $('#btnValidate');
        var btnFormat = $('#btnFormat');
        var isJsonContentChanged = false;
        var mapping = [];
        var aceMarkers = [];
        var uidsToHighlight = [];
        var rawStatus = $('#divRawEditorStatus');
        var gridViewer = $('#gridViewer');

        function clearStatusBar() {
            rawStatus.html('<i class="glyphicon glyphicon-check"></i><b>&nbsp;Ready</b>');
        }
        function statusBar_Error(msg) {
            rawStatus.html('<i class="glyphicon glyphicon-alert" style="color:#E74C3C;"></i><b>&nbsp;&nbsp;' + msg + '</b>');
        }

        function highlightLine(lineNo) {
            lineNo = decrypt(lineNo, 7, 73);
            var Range = ace.require('ace/range').Range;
            var marker = editor.session.addMarker(new Range(lineNo - 1, 0, lineNo - 1, Infinity), "json-editor-highlight-line", "fullLine");
            aceMarkers.push(marker);
        }

        function repeteHighlight() {
            jsonEditorHighlight(uidsToHighlight);
        }

        function jsonEditorHighlight(uids) {
            uidsToHighlight = uids;
            clearHighlightedLines();
            var lineNos = [];
            for (var i = 0; i < uids.length; i++) {
                var foundArr = mapping.filter(function (item) { return decrypt(item.u, 3, 23) == uids[i] });
                for (var j = 0; j < foundArr.length; j++) {
                    var found = foundArr[j];
                    if (lineNos.indexOf(found.l) == -1) {
                        lineNos.push(found.l);
                    }
                }
            }
            for (var i = 0; i < lineNos.length; i++) {
                highlightLine(lineNos[i]);
            }

            if (lineNos.length > 0) {
                lineNos.sort();
                var first = decrypt(lineNos[0], 7, 73);
                editor.gotoLine(first, 0, true);
            }
        }

        function decrypt(number, multiply, add) {
            return ((number - add) / multiply);
        }

        function clearHighlightedLines() {
            for (var i = 0; i < aceMarkers.length; i++) {
                editor.getSession().removeMarker(aceMarkers[i]);
            }
        }

        function clearJsonEditor() {
            editor.setValue('', 0);
        }

        function postReceivedData_format(data) {
            numberOfLines = data.l; //totallines
            mapping = data.m; //mapping
        }

        function minify() {
            verifyJsonError();
            var sourceText = editor.getValue();
            var sourceJson = JSON.parse(sourceText);
            var text = JSON.stringify(sourceJson);
            editor.setValue(text);
        }

        function isJsonChanged(reset) {
            var val = isJsonContentChanged;
            if (reset)
                isJsonContentChanged = false;
            return val;
        }

        function onLoad() {
            editor = ace.edit("jsonEditor");

            if ($root.state.getSettings($root.constants.Settings.THEME) == $root.constants.Theme.DARK)
                editor.setTheme("ace/theme/idle_fingers"); //dark
            else
                editor.setTheme("ace/theme/dawn"); //light

            editor.getSession().setMode("ace/mode/json");

            editor.setOptions({ fontSize: "13px" });

            editor.on('change', function () {
                isJsonContentChanged = true;
            });
            editor.getSession().setUseWrapMode(true)

            preloadInJsonEditor();
        }

        function preloadInJsonEditor() {
            var hasGuid = $root.state.hasGuid();
            if (hasGuid) {
                editor.setValue('');
                editor.gotoLine(1, 0, true);
                gridViewer.html('');
                isJsonContentChanged = true;
            }
            else {
                $root.state.createGuid();

                loadSample();

                $root.site.getBackend(function () {
                    setTimeout(function () {
                        $('#btnExpandAll').click();
                        $('[gid="9"]').click();
                        editor.gotoLine(1, 0, true);
                    }, 500);
                });
            }
        }

        function loadSample() {
            var sampleJson = { "squadName": "Super hero squad", "homeTown": "Metro City", "formed": 2016, "secretBase": "Super tower", "active": true, "members": [{ "index": 0, "isActive": false, "age": 21, "eyeColor": "blue", "name": "Bentley Clayton", "gender": "male", "registered": "2018-05-02T05:35:41 +04:00" }, { "index": 1, "isActive": false, "age": 23, "eyeColor": "blue", "name": "Lela Ramos", "gender": "female", "registered": "2014-02-24T03:13:50 +05:00" }, { "index": 2, "isActive": true, "age": 38, "eyeColor": "green", "name": "Milagros Becker", "gender": "female", "registered": "2016-10-22T12:18:50 +04:00" }, { "index": 3, "isActive": false, "age": 30, "eyeColor": "brown", "name": "Mccoy Barrera", "gender": "male", "registered": "2016-12-03T03:44:57 +05:00" }, { "index": 4, "isActive": false, "age": 35, "eyeColor": "brown", "name": "Morton Bennett", "gender": "male", "registered": "2015-10-06T09:48:03 +04:00" }, { "index": 5, "isActive": true, "age": 20, "eyeColor": "blue", "name": "Acosta Bird", "gender": "male", "registered": "2019-02-11T09:59:58 +05:00" }, { "index": 6, "isActive": false, "age": 35, "eyeColor": "blue", "name": "Mcleod Keith", "gender": "male", "registered": "2014-04-24T07:50:11 +04:00" }, { "index": 7, "isActive": false, "age": 27, "eyeColor": "brown", "name": "Magdalena Burgess", "gender": "female", "registered": "2015-03-19T09:28:55 +04:00" }, { "index": 8, "isActive": false, "age": 37, "eyeColor": "blue", "name": "Cline Castaneda", "gender": "male", "registered": "2016-02-29T09:49:37 +05:00" }, { "index": 9, "isActive": false, "age": 39, "eyeColor": "green", "name": "Garcia Baker", "gender": "male", "registered": "2018-05-26T02:54:22 +04:00" }, { "index": 10, "isActive": true, "age": 40, "eyeColor": "blue", "name": "Lenora Keller", "gender": "female", "registered": "2017-12-19T05:12:17 +05:00" }, { "index": 11, "isActive": false, "age": 33, "eyeColor": "green", "name": "Kathryn Donovan", "gender": "female", "registered": "2014-03-21T12:33:36 +04:00" }, { "index": 12, "isActive": true, "age": 40, "eyeColor": "blue", "name": "Opal Hinton", "gender": "female", "registered": "2014-05-03T02:14:25 +04:00" }, { "index": 13, "isActive": false, "age": 25, "eyeColor": "green", "name": "Mayer Gray", "gender": "male", "registered": "2016-04-01T05:52:21 +04:00" }, { "index": 14, "isActive": true, "age": 22, "eyeColor": "green", "name": "Josefina Quinn", "gender": "female", "registered": "2015-02-07T12:04:14 +05:00" }] };
            var formattedJson = JSON.stringify(sampleJson, null, "\t");
            editor.setValue(formattedJson);
            isJsonContentChanged = true;
        }

        function getValue() {
            return editor.getValue();
        }

        function getErrors() {
            return editor.getSession().getAnnotations();
        }

        function verifyJsonError() {
            var errors = getErrors();
            if (errors.length > 0) {
                var error = errors[0];
                $root.toast.error('Error at line: ' + error.row, error.text, 5000);
                statusBar_Error('Error at line: ' + error.row + '.&nbsp;&nbsp;&nbsp;' + error.text);
                editor.gotoLine(error.row, 0, true);

                return { hasError: true, json: null };
            }
            else {
                clearStatusBar();
                var _json = JSON.parse(getValue());
                editor.setValue(JSON.stringify(_json, null, "\t"));
                editor.gotoLine(1, 0, true);
                setTimeout(function () { isJsonContentChanged = false; }, 100); //Setting value hits onChange event, which let tabChange hitting backend call without change
                return { hasError: false, json: _json };
            }
        }

        function validateJson() {
            var res = verifyJsonError();
            if (!res.hasError) {
                $root.toast.basic('JSON is valid !!', 3000);
            }
        }

        function formatJson() {
            var res = verifyJsonError();
            if (!res.hasError) {
                $root.toast.basic('JSON formatted successfully !!', 3000);
            }
        }

        //public methods
        this.minify = minify;
        this.postReceivedData_format = postReceivedData_format;
        this.clearJsonEditor = clearJsonEditor;
        this.jsonEditorHighlight = jsonEditorHighlight;
        this.isJsonChanged = isJsonChanged;
        this.onLoad = onLoad;
        this.getValue = getValue;
        this.repeteHighlight = repeteHighlight;
        this.getErrors = getErrors;
        this.verifyJsonError = verifyJsonError;

        //Events
        btnClear.on('click', function () { clearJsonEditor(); });
        btnMinify.on('click', function () { minify(); });
        btnSample.on('click', function () { loadSample(); });
        btnValidate.on('click', function () { validateJson(); });
        btnFormat.on('click', function () { formatJson(); })
    }

    $root.jsonEditor = new JsonEditor();
})();