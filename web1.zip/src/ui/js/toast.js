/* requires:
root.js
utils.js
*/

//https://kamranahmed.info/toast

(function () {
    function Toast() {
        function basic(msg, _hideAfter) {
            $.toast({
                text: msg,
                allowToastClose: false,
                hideAfter: _hideAfter || false,
                bgColor: getBgColor(),
                position: 'mid-center',
                textAlign: 'center'
            });
        }

        function processing(msg) {
            var processingGlyphicon = '<i class="glyphicon glyphicon-refresh glyphicon-spin"></i>&nbsp;&nbsp;';
            $.toast({
                text: processingGlyphicon + msg,
                allowToastClose: false,
                hideAfter: false,
                bgColor: getBgColor(),
                position: 'mid-center',
                textAlign: 'center'
            });
        }

        function warning(heading, msg) {
            setTimeout(function () {
                $.toast({
                    heading: heading,
                    text: msg,
                    icon: 'warning',
                    allowToastClose: true,
                    hideAfter: 10000,
                    showHideTransition: 'plain',
                    position: 'mid-center',
                    textAlign: 'center'
                });
            }, 10);
        }

        function error(heading, msg, _hideAfter) {
            setTimeout(function () {
                $.toast({
                    heading: heading,
                    text: msg,
                    icon: 'error',
                    allowToastClose: true,
                    hideAfter: _hideAfter || 5000,
                    showHideTransition: 'plain',
                    position: 'mid-center',
                    textAlign: 'center'
                });
            }, 10);
        }

        function clearAll() {
            $.toast().reset('all');
        }

        //private methods
        function getBgColor() {
            if ($root.state.getSettings($root.constants.Settings.THEME) == $root.constants.Theme.DARK) {
                return '#68989c';
            }
            else {
                return '';
            }
        }

        //public methods
        this.basic = basic;
        this.clearAll = clearAll;
        this.processing = processing;
        this.warning = warning;
        this.error = error;
    }

    $root.toast = new Toast();
})();