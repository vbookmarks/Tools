/* requires:
root.js
constants.js
state.js
utils.js
toast.js
lazyLoader.js
rawEditor.js
jsonEditor.js
gridViewer.js
*/

(function () {
    function Site() {
        var leftContainer = $('#leftContainer');
        var rightContainer = $('#rightContainer');
        var btnGetBackend = $('#btnGetBackend');
        var mainContainer = $('#mainContainer');
        var jsonEditor = $('#jsonEditor');
        var dragger = $('#dragger');
        var btnSaveSettings = $('#btnSaveSettings');
        var rdThemeDark = $('#rdThemeDark');
        var rdThemeLite = $('#rdThemeLite');
        var rdViewSplit = $('#rdViewSplit');
        var rdViewTab = $('#rdViewTab');
        var modalPopupSettings = $('#modalPopupSettings');
        var modalConfirm = $('#modalConfirm');
        var btnProceedSaveSettings = $('#btnProceedSaveSettings');
        var btnCancelSaveSettings = $('#btnCancelSaveSettings');
        var btnCancelProceed = $('#btnCancelProceed');

        function getBackend(callback) {
            var parseResult = $root.jsonEditor.verifyJsonError();

            if (parseResult.hasError)
                return;

            $root.toast.processing('Processing..');
            var sourceJson = JSON.stringify(parseResult.json);
            sourceJson = $root.util.aesEncrypt('kymy9umth2ct3f3i', sourceJson);
            sourceJson = JSON.stringify(JSON.parse('{ "authToken": "' + sourceJson + '"}'));
            var url = "api/authentication/verify-auth-token";

            emptyStatus();

            $.ajax({
                url: url,
                type: 'post',
                dataType: 'json',
                contentType: 'application/json',
                success: function (response) {
                    response = JSON.parse($root.util.aesDecrypt('idrc91e3s7rksi00', response.authToken));
                    $root.jsonEditor.postReceivedData_format(response.format);
                    $root.gridViewer.postReceivedData_grid(response.grid);
                    $root.toast.clearAll();

                    if (callback != null && typeof callback == "function") callback();
                },
                data: sourceJson
            });
        }

        function resizeContent() {
            var bottomGap = 60; //For SplitView
            if ($root.state.getSettings($root.constants.Settings.VIEW) == $root.constants.View.TAB)
                bottomGap = 110;
            var $height = $(window).height() - bottomGap;
            mainContainer.height($height);
            jsonEditor.height($height - 62);
        }

        function siteOnLoad() {
            $root.util.splitter(mainContainer, leftContainer, dragger, rightContainer);

            resizeContent();

            $(window).resize(function () {
                resizeContent();
            });

            emptyStatus();
            loadSettings();
        }

        function onLoad() {
            if ($root.state.getSettings($root.constants.Settings.VIEW) == $root.constants.View.TAB) {
                tabViewFuncs();
            }

            $(document).ready(function () {
                siteOnLoad();

                //Don't perform any rawEdior functions if they are loading in fullScreen View
                if (!$root.gridViewer.isOpenedInFullScreenView()) {
                    $root.jsonEditor.onLoad();
                }
            });
        }

        function tabViewFuncs() {
            var gridTab = $('#gridTab');
            var jsonTab = $('#jsonTab');
            var gridTabContent = $('#grid');
            var jsonTabContent = $('#json');

            gridTab.on('click', function () {
                jsonTab.removeClass('active');
                gridTab.removeClass('active');
                gridTab.addClass('active');

                if ($root.jsonEditor.isJsonChanged(true)) {
                    $root.site.getBackend();
                }
            });

            jsonTab.on('click', function () {
                jsonTab.removeClass('active');
                gridTab.removeClass('active');
                jsonTab.addClass('active');

                setTimeout(function () {
                    $root.jsonEditor.repeteHighlight();
                }, 100);
            });

            var $height = $(window).height() - 108;
            leftContainer.css({ 'width': '100%' });
            rightContainer.css({ 'width': '100%' });

            gridTabContent.css({ 'width': '100%', 'height': $height });
            jsonTabContent.css({ 'width': '100%', 'height': $height });
        }

        function emptyStatus() {
            $root.gridViewer.gridViewerStatus('E');
        }

        //Settings related methods
        function saveSettings() {
            modalPopupSettings.modal('toggle');
            modalConfirm.modal('toggle');
        }

        function proceedSaveSettings() {
            if (rdThemeDark.prop('checked'))
                $root.state.saveSettings($root.constants.Settings.THEME, $root.constants.Theme.DARK);
            else if (rdThemeLite.prop('checked'))
                $root.state.saveSettings($root.constants.Settings.THEME, $root.constants.Theme.LITE);

            if (rdViewSplit.prop('checked'))
                $root.state.saveSettings($root.constants.Settings.VIEW, $root.constants.View.SPLIT);
            else if (rdViewTab.prop('checked'))
                $root.state.saveSettings($root.constants.Settings.VIEW, $root.constants.View.TAB);

            modalConfirm.modal('toggle');
            window.location.reload();
        }

        function cancelSaveSettings() {
            loadSettings();
            modalPopupSettings.modal('toggle');
        }

        function cancelProceed() {
            loadSettings();
            modalConfirm.modal('toggle');
        }

        function loadSettings() {
            var _theme = $root.state.getSettings($root.constants.Settings.THEME);
            var _view = $root.state.getSettings($root.constants.Settings.VIEW);

            rdThemeDark.prop('checked', (_theme == 'D'));
            rdThemeLite.prop('checked', (_theme == 'L'));

            rdViewSplit.prop('checked', (_view == 'S'));
            rdViewTab.prop('checked', _view == 'T');
        }

        this.getBackend = getBackend;
        this.onLoad = onLoad;

        //Events
        btnGetBackend.on('click', getBackend);
        btnSaveSettings.on('click', saveSettings);
        btnProceedSaveSettings.on('click', proceedSaveSettings);
        btnCancelSaveSettings.on('click', cancelSaveSettings);
        btnCancelProceed.on('click', cancelProceed);
    }

    $root.site = new Site();

    $root.site.onLoad();
})();