/* requires:
root.js
utils.js
toast.js
lazyLoader.js
*/
(function () {
    function RawEditor() {
        var editor = $('#rawEditor');
        var cont = $('#rawContainer');
        var ln = $('#rawLineNoList');
        var btnClear = $('#btnClear');
        var btnMinify = $('#btnMinify');
        var btnSample = $('#btnSample');
        var progBarCont = $('#rawEditorProgressBarContainer');
        var progBar = $('#rawEditorProgressBar');
        var rawStatus = $('#divRawEditorStatus');
        var maxLinesSupported = 10000;
        var msgOverMaxLines = 'Grid-Connect is not supported over ' + $root.util.numberWithCommas(maxLinesSupported) + ' lines for now!';
        var numberOfLines = 0;
        var isJsonContentChanged = true;

        var delayExecuteFunc = $root.lazyLoader.delayExecute(200);
        var glyphicon = {
            ALERT: '<i class="glyphicon glyphicon-alert"></i>',
            SPINNER: '<i class="glyphicon glyphicon-refresh glyphicon-spin"></i>',
            READY: '<i class="glyphicon glyphicon-check"></i>'
        };
        var enumStaus = {
            EMPTY: 'E',
            LOADING: 'L',
            READY: 'R',
            WAITING: 'W',
            NOTSUPPORTED: 'N'
        };

        function progressBar(_progress) {
            if (_progress == 0 || _progress == 100) {
                progBar.width(1);
                progBarCont.hide();
            }
            else {
                progBarCont.show();
                progBar.width(_progress);
            }
        }

        function rawEditorStatus(_status) {
            if (_status == enumStaus.EMPTY) {
                rawStatus.html('');
            }
            else if (_status == enumStaus.LOADING) {
                rawStatus.html(glyphicon.SPINNER + '<b>&nbsp;Loading....</b>');
            }
            else if (_status == enumStaus.READY) {
                rawStatus.html(glyphicon.READY + '<b>&nbsp;Ready</b>');
            }
            else if (_status == enumStaus.WAITING) {
                rawStatus.html(glyphicon.SPINNER + '<b>&nbsp;Waiting....</b>');
            }
            else if (_status == enumStaus.NOTSUPPORTED) {
                rawStatus.html('<b><a href="javascript:void(0);" title="' + msgOverMaxLines + '">' + glyphicon.ALERT + '</a>&nbsp;&nbsp;Ready');
            }
        }

        function fillRawEditor(arrLines) {
            ln.html('');
            editor.html('');
            rawEditorStatus(enumStaus.LOADING);
            $root.lazyLoader.htmlLinesLoad(arrLines, editor, function (percent) {
                progressBar(parseInt(percent));
                if (percent == 100) {
                    rawEditorStatus(enumStaus.READY);
                    editor.height(cont[0].scrollHeight);
                    addLineNumbersFunc();
                    isJsonContentChanged = false;
                }
            });
        }

        function preFillRawEditor() {
            cont.removeClass('display-flex');
        }

        function postFillRawEditor() {
            var h = editor.height();
            cont.addClass('display-flex');
            if (h > cont.height())
                editor.height(h);

            rawEditorScrollTop(0);
        }

        function resetLinoList() {
            ln.html('<div>1</div>');
        }

        function rawEditorScrollTop(topVal) {
            cont.animate({
                'scrollTop': topVal
            }, 500);
        }

        function rawEditorHighlightItem(uid) {
            setTimeout(function (uid) {
                editor.find('span[uid="' + uid + '"]').addClass('highlight-format');
            }, 1, uid);
        }

        function addLineNumbersFunc() {
            var cTop = cont[0].scrollTop;
            var cBott = cTop + cont.height();
            for (var i = 0; i < numberOfLines; i++) {
                var t = $('#ln_' + (i + 1))[0].offsetTop;
                var h = $('#ln_' + (i + 1))[0].clientHeight;
                if (t >= cTop && t < cBott) {
                    ln.append("<div style='height:" + h + "px'>" + (i + 1) + "</div>");
                }
            }
        }

        function rawEditorHighlight(uids) {
            editor.find('[uid]').removeClass('highlight-format');

            if (uids.length > 0) {
                var firstUid = uids[0];
                var firstElement = editor.find('span[uid="' + firstUid + '"]');
                rawEditorScrollTop(firstElement[0].offsetTop - 100);
            }

            if (uids.length <= 200) {
                for (var i = 0; i < uids.length; i++) {
                    rawEditorHighlightItem(uids[i]);
                }
            }
            else {
                $root.util.log('Highlight: More than 200 items to highlight.');
            }
        }

        function clearRawEditor() {
            editor.html('');
            resetLinoList();
            rawEditorScrollTop(0);
            rawEditorStatus(enumStaus.EMPTY);
        }

        function postReceivedData_format(data) {
            numberOfLines = data.totalLines;
            var mapping = data.mapping;
            $root.toast.clearAll();
            if (numberOfLines > maxLinesSupported) {
                rawEditorStatus(enumStaus.NOTSUPPORTED);
            }
            else {
                fillRawEditor(data.formattedJson);
            }
        }

        function supportLargeTextPaste(e) {
            var self = e.target;
            $root.toast.processing('Pasting Large Content..');
            var clen = self.innerText.length;
            var slen = window.getSelection().toString().length;

            if (slen != clen) {
                if (clen != 0) {
                    $root.toast.clearAll();
                    return;
                }
            }
            preFillRawEditor();

            e.preventDefault();// cancel paste
            var text = (e.originalEvent || e).clipboardData.getData('text/plain');// get text representation of clipboard

            setTimeout(function () {
                $(self).html(text);
                $root.toast.clearAll();
            }, 300);
            postFillRawEditor();
            editor.trigger('change');
        }

        function removeUnicodeUA00Char(str) {
            str = str.split(/\u00A0/).join(" ");
            return str; //.split('\\').join('\\\\');
        }

        function minify() {
            var sourceText = editor.text();
            sourceText = removeUnicodeUA00Char(sourceText);
            var sourceJson = JSON.parse(sourceText);
            var text = JSON.stringify(sourceJson);
            editor.text(text);
            resetLinoList();
        }

        function addLineNumbers() {
            ln.html('');
            delayExecuteFunc(function () {
                addLineNumbersFunc();
            });
        }

        function fixLineNoPosition() {
            var cTop = cont[0].scrollTop;
            ln.css('margin-top', cTop);
        }

        function isJsonChanged() {
            return isJsonContentChanged;
        }

        function onLoad() {
            clearRawEditor();

            //rawEditor's change event
            editor.on('focus', function () {
                before = $(this).html();
            }).on('blur input paste', function () {
                if (before != $(this).html()) { $(this).trigger('change'); }
            });
            
            loadSample();
            $root.site.getBackend(function () {
                setTimeout(function () { $('[gid="9"]').click(); }, 500);   
            });
        }

        function loadSample() {
            var sampleJson = { "squadName": "Super hero squad", "homeTown": "Metro City", "formed": 2016, "secretBase": "Super tower", "active": true, "members": [{ "name": "Molecule Man", "age": 29, "secretIdentity": "Dan Jukes", "powers": ["Radiation resistance", "Turning tiny", "Radiation blast"] }, { "name": "Madame Uppercut", "age": 39, "secretIdentity": "Jane Wilson", "powers": ["Million tonne punch", "Damage resistance", "Superhuman reflexes"] }, { "name": "Eternal Flame", "age": 1000000, "secretIdentity": "Unknown", "powers": ["Immortality", "Heat Immunity", "Inferno", "Teleportation", "Interdimensional travel"] }] };
            var formattedJson = JSON.stringify(sampleJson, null, "\t");
            editor.html(formattedJson);
            isJsonContentChanged = true;
        }

        //public methods
        this.minify = minify;
        this.postReceivedData_format = postReceivedData_format;
        this.clearRawEditor = clearRawEditor;
        this.rawEditorHighlight = rawEditorHighlight;
        this.removeUnicodeUA00Char = removeUnicodeUA00Char;
        this.rawEditorStatus = rawEditorStatus;
        this.isJsonChanged = isJsonChanged;
        this.onLoad = onLoad;

        //Events
        btnClear.on('click', function () { clearRawEditor(); });
        btnMinify.on('click', function () { minify(); });
        cont.on('scroll', function () { addLineNumbers(); fixLineNoPosition(); });
        btnSample.on('click', function () { loadSample(); });
        editor.on('paste', function (e) { supportLargeTextPaste(e) });
        editor.on('change', function () { isJsonContentChanged = true; });
    }

    $root.rawEditor = new RawEditor();
})();