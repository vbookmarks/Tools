/* requires:
root.js
*/
(function () {
    function Utils() {
        function log(msg) {
            var d = new Date();
            console.log('[INFO: ' + d.toLocaleString() + '.' + d.getMilliseconds() + '] ' + msg);
        }

        function splitter(mainContainer,leftDiv, dragger, rightDiv) {
            var lStop = leftDiv.width() * 85 / 100;
            var rStop = rightDiv[0].offsetLeft + rightDiv.width() * 85 / 100;
            var draggerWidth = dragger.width();
            dragger.bind('mousedown', function (ed) {
                var oldX = ed.pageX;
                $(document).bind('mousemove', function (em) {
                    var newX = em.pageX;

                    var diff = newX - oldX;
                    oldX = newX;

                    var lVal = leftDiv.width() + diff;
                    var rVal = rightDiv.width() - (diff);

                    if (newX < lStop || newX > rStop) {
                        return;
                    }
                    leftDiv.width(lVal);
                    rightDiv.width(rVal);
                    dragger.width(draggerWidth);
                    mainContainer.width(lVal + draggerWidth + rVal);
                });
            });

            $(document).bind('mouseup', function () {
                $(document).unbind('mousemove');
            });
        }

        function numberWithCommas(x) {
            return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        }

        function aesEncrypt(secretKey, textToEncrypt) {
            var ciphertext = CryptoJS.AES.encrypt(textToEncrypt, secretKey);
            return ciphertext;
        }
        function aesDecrypt(secretKey, textToDecrypt) {
            var bytes  = CryptoJS.AES.decrypt(textToDecrypt.toString(), secretKey);
            var plaintext = bytes.toString(CryptoJS.enc.Utf8);
            return plaintext;
        }
        
        this.log = log;
        this.aesEncrypt = aesEncrypt;
        this.aesDecrypt = aesDecrypt;
        this.numberWithCommas = numberWithCommas;
        this.splitter = splitter;
    }
    $root.util = new Utils();
})();