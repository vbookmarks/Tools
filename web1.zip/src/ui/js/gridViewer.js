/* requires:
root.js
constants.js
utils.js
state.js
toast.js
lazyLoader.js
jsonEditor.js
rawEditor.js
*/
(function () {

    function GridViewer() {
        var rightContainer = $('#rightContainer');
        var gridViewer = $('#gridViewer');
        var btnCollapseAll = $('#btnCollapseAll');
        var btnExpandAll = $('#btnExpandAll');
        var btnFullScreen = $('#btnFullScreen');

        var pnlSearch = $('#pnlSearch');
        var btnSearch = $('#btnSearch');
        var txtSearch = $('#txtSearch');
        var lblSearchIndex = $('#lblSearchIndex');
        var btnSearchPrev = $('#btnSearchPrev');
        var btnSearchNext = $('#btnSearchNext');
        var btnSearchClose = $('#btnSearchClose');
        var gridStatus = $('#divGridViewerStatus');
        var tblMenuOpener = $('#tblMenuOpener');

        var delayExecuteFunc = $root.lazyLoader.delayExecute(1000);
        var enumStaus = {
            EMPTY: 'E',
            LOADING: 'L',
            READY: 'R',
            WAITING: 'W'
        };

        function isOpenedInFullScreenView() {
            return document.title.indexOf('Full Screen') > 0;
        }

        function gridViewerStatus(_status) {
            if (_status == enumStaus.EMPTY) {
                gridStatus.html('');
            }
            else if (_status == enumStaus.LOADING) {
                gridStatus.html('<b><i class="glyphicon glyphicon-refresh glyphicon-spin"></i>&nbsp;Loading....</b>');
            }
            else if (_status == enumStaus.READY) {
                gridStatus.html('<b><i class="glyphicon glyphicon-check"></i>&nbsp;Ready</b>');
            }
            else if (_status == enumStaus.WAITING) {
                gridStatus.html('<b><i class="glyphicon glyphicon-refresh glyphicon-spin"></i>&nbsp;Waiting....</b>');
            }
        }

        function postReceivedData_grid(htmlString) {
            gridViewer.html(htmlString);

            collapseAll();
            openFirstLevel();
            clearSearchPanel();
            gridViewerStatus(enumStaus.READY);
        }

        function clearSearchPanel() {
            pnlSearch.hide('slow');
            txtSearch.val('');
            lblSearchIndex.html('Empty');
            lblSearchIndex.attr({ 'total': 0, 'current': 0 });
        }

        function openFirstLevel() {
            $('span:contains("[+]")').parent().find('.tblcontainer').hide();
        }

        function expandAll() {
            $('span.plusminus').parent().find('.tblcontainer').show();
            $('span.plusminus').html('[-]');
        }

        function collapseAll() {
            $('span.plusminus').parent().find('.tblcontainer').hide();
            $('span.plusminus').html('[+]');
        }

        function extractGid(elements) {
            var gids = [];
            elements.each(function (index, element) {
                var gid = $(element).attr('gid');
                gids.push(parseInt(gid));

                var kgid = $(element).attr('kgid');
                if (kgid)
                    gids.push(parseInt(kgid));

            });
            gids = gids.sort(sortNumber);
            gids = gids.filter(function (item, i, ar) { return ar.indexOf(item) === i; }); //unique values only
            return gids;
        }

        function sortNumber(a, b) {
            return a - b;
        }

        function findInTable(self) {
            var table = self.closest('table')
            table.addClass('highlight');
            var elements = table.find('[gid]');
            elements.push(self);
            var gids = extractGid(elements);
            return gids;
        }

        function findInCell(self) {
            self.addClass('highlight');
            var elements = self.find('[gid]');
            elements.push(self);
            var gids = extractGid(elements);
            return gids;
        }

        function findInRow(self) {
            var tr = self.closest('tr');
            tr.addClass('highlight');
            var elements = tr.find('[gid]');
            var gids = extractGid(elements);
            return gids;
        }

        function findInColumn(self) {
            var gIdsArr = [];
            var colIndex = self.index();
            var parentTable = self.closest('table');
            var trs = parentTable.find('> tbody').find('> tr');
            trs.each(function (index, tr) {
                var tr = $(tr);
                var td = tr.find('td').eq(colIndex);
                td.addClass('highlight');
                var elements = td.find('[gid]');
                elements.push(td);
                var gids = extractGid(elements);
                gIdsArr = gIdsArr.concat(gids);
            });
            return gIdsArr;
        }

        function highlightOnTop(event) {
            var target = $(event.target);
            $('div.tbl-menu').hide();
            if (target.attr('name') == 'tblMenuOpener') {
                addTableMenu(target);
                return;
            }
            if (target.attr('class') == 'plusminus')
                toggle(target, event);
            else
                highlight(event, target);
        }

        function addTableMenu(target) {
            var menuContainer = target.parent();
            var menu = menuContainer.find('div.tbl-menu');
            if (menu.length == 0) {
                var div = document.createElement('div');
                div.innerHTML = 'Export To CSV'; div.className = 'tbl-menu';
                menuContainer.append(div);
                $(div).on('click', function (e) {
                    $root.toast.processing('Generating CSV');
                    setTimeout(function () {
                        exportTableToCSV(target.closest('table'), 'export.csv');
                        $root.toast.clearAll();
                    }, 10);
                    $(this).hide();
                    e.stopPropagation();
                })
            }
            else
                menu.show();
        }

        function exportTableToCSV($table, filename) {

            var delimeter = ',';
            var newLine = '\r\n';
            var csv = '';

            var th = $table.children('tbody').children('tr:eq(0)').children('th');
            for (var i = 1; i < th.length; i++) {
                csv += wrap($(th[i]).text().replace(/"/g, '""')) + delimeter;
            }
            csv += newLine;

            var tr = $table.children('tbody').children('tr');
            for (var i = 1; i < tr.length; i++) {
                var td = $(tr[i]).children('td');
                for (var j = 1; j < td.length; j++) {
                    if ($(td[j]).find('span.plusminus').length > 0)
                        csv += '' + delimeter;
                    else
                        csv += wrap($(td[j]).text().replace(/"/g, '""')) + delimeter;
                }
                csv += newLine;
            }

            var downloadLink = document.createElement("a");
            var blob = new Blob(["\ufeff", csv]);
            var url = URL.createObjectURL(blob);
            downloadLink.href = url;
            downloadLink.download = filename;

            document.body.appendChild(downloadLink);
            downloadLink.click();
            document.body.removeChild(downloadLink);

            function wrap(_text) {
                return '"' + _text + '"';
            }
        }

        function highlight(event, self) {
            gridViewer.find('.highlight').removeClass('highlight');
            var self = $(self).closest('[type]');
            var type = self.attr("type");
            var gid = self.attr("gid");
            var gids = [];
            if (type == 'table') {
                gids = findInTable(self);
            }
            if (type == 'cell') {
                gids = findInCell(self);
            }
            else if (type == 'row') {
                gids = findInRow(self);
            }
            else if (type == 'column') {
                gids = findInColumn(self);
            }

            event.stopPropagation();

            if (!isOpenedInFullScreenView())
                $root.jsonEditor.jsonEditorHighlight(gids);
        }

        function toggle(self, event) {
            var div = $(self).parent().find('.tblcontainer:eq(0)');
            if (div.is(":visible")) {
                div.hide();
                $(self).html("[+]");
            }
            else {
                div.show();
                $(self).html("[-]");
            }
            event.stopPropagation();
        }

        function findElementsDirectlyContainingText(ancestor, text) {
            var elements = [];
            walk(ancestor);
            return elements;

            function walk(element) {
                var n = element.childNodes.length;
                for (var i = 0; i < n; i++) {
                    var child = element.childNodes[i];
                    if (child.nodeType === 3 && child.data.toLowerCase().indexOf(text.toLowerCase()) !== -1) {
                        elements.push(element);
                        break;
                    }
                }
                for (var i = 0; i < n; i++) {
                    var child = element.childNodes[i];
                    if (child.nodeType === 1)
                        walk(child);
                }
            }
        }

        function searchText(index) {

            //Remove all highlight
            clearSearchHighlight();

            if (txtSearch.val() == '') {
                lblSearchIndex.attr({ 'total': 0, 'current': 0 });
                txtSearch.html('Empty')
                return;
            }
            //1. Search value in grid, get list of all elements
            var text = txtSearch.val();
            var elements = findElementsDirectlyContainingText(gridViewer[0], text);

            //2. Populate index label, either with numbers of 'Not found'
            if (elements.length == 0) {
                lblSearchIndex.attr({ 'total': 0, 'current': 0 });
                lblSearchIndex.html('Not found');
                return;
            }
            else {
                lblSearchIndex.attr({ 'total': elements.length, 'current': index });
                lblSearchIndex.html(index + ' of ' + elements.length);
            }

            //3. Expand All
            expandAll();

            //4. Highlight text in all elements in HTML
            for (var i = 0; i < elements.length; i++) {
                var element = $(elements[i]);
                //var content = element.html();
                //content = content.split(text).join('<span class="search-soft-highlight">' + text + '</span>');
                //element.html(content);
                element.addClass('search-soft-highlight');
            }
            //5. Take element based on index, Move scroll it, double highlight it

            var elementOffset = tdOffset(elements[index - 1]);

            gridViewer.find('td.search-highlight, th.search-highlight, span.search-highlight').removeClass('search-highlight');
            $(elements[index - 1]).addClass('search-highlight');

            gridViewer.animate({ 'scrollLeft': elementOffset.left - 700 }, 0);
            gridViewer.animate({ 'scrollTop': elementOffset.top - 200 }, 0);
        }

        function clearSearchHighlight() {
            gridViewer.find('td.search-soft-highlight, th.search-soft-highlight, span.search-soft-highlight').removeClass('search-soft-highlight');
            gridViewer.find('td.search-highlight, th.search-highlight, span.search-highlight').removeClass('search-highlight');
        }

        function searchNext() {
            var total = parseInt(lblSearchIndex.attr('total'));
            var current = parseInt(lblSearchIndex.attr('current'));

            if (total == 0 || current == total) {
                return;
            }
            else {
                current = current + 1;
                searchText(current);
            }
        }

        function searchPrev() {
            var total = parseInt(lblSearchIndex.attr('total'));
            var current = parseInt(lblSearchIndex.attr('current'));

            if (total == 0 || current == 1) {
                return;
            }
            else {
                current = current - 1;
                searchText(current);
            }
        }

        function tdOffset(elem) {
            if (!elem) elem = this;

            var x = elem.offsetLeft;
            var y = elem.offsetTop;

            while (elem = elem.offsetParent) {
                x += elem.offsetLeft;
                y += elem.offsetTop;
            }

            return { left: x, top: y };
        }

        function fullScreen() {
            var params = [
                'height=' + screen.height,
                'width=' + screen.width,
                'fullscreen=yes', // only works in IE, but here for completeness
                'location=no,toolbar=no,menubar=no,scrollbars=yes,resizable=yes'
            ].join(',');

            var win = window.open('', 'Grid', params);
            win.moveTo(0, 0);
            var doc = win.document;
            var links = collectHtmlTag('link');
            var scripts = collectHtmlTag('script');

            var rightContainerHtml = rightContainer[0].outerHTML;
            doc.open();
            doc.write('<html><head><title>Grid - Full Screen</title>' + links + '</head>');
            doc.write(rightContainerHtml);
            doc.write('</body></html>');
            doc.write(scripts);

            doc.close();

            var win_rightContainer = $(doc).find('#rightContainer');
            var win_btnFullScreen = $(doc).find('#btnFullScreen');
            win_rightContainer.width('100%');
            win_btnFullScreen.hide();
        }

        function collectHtmlTag(tagName) {
            var tags = $(tagName);
            var tagHtml = '';
            for (var i = 0; i < tags.length; i++) {
                if (!($(tags[i]).attr('reload') && $(tags[i]).attr('reload') == 'false')) {
                    tagHtml += tags[i].outerHTML;
                }
            }
            return tagHtml;
        }

        this.highlight = highlight;
        this.postReceivedData_grid = postReceivedData_grid;
        this.toggle = toggle;
        this.highlightOnTop = highlightOnTop;
        this.searchText = findElementsDirectlyContainingText;
        this.gridViewerStatus = gridViewerStatus;
        this.isOpenedInFullScreenView = isOpenedInFullScreenView;

        //Events
        gridViewer.on('click', function (e) { highlightOnTop(e); });
        btnExpandAll.on('click', function () { expandAll(); });
        btnCollapseAll.on('click', function () { collapseAll(); });
        btnFullScreen.on('click', function () { fullScreen(); });
        btnSearch.on('click', function () { pnlSearch.show('slow'); txtSearch.focus(); });
        btnSearchClose.on('click', function () { clearSearchPanel(); clearSearchHighlight(); });
        txtSearch.on('keyup', function () { delayExecuteFunc(function () { searchText(1); }); });
        btnSearchNext.on('click', function () { searchNext(); });
        btnSearchPrev.on('click', function () { searchPrev(); });
    }

    $root.gridViewer = new GridViewer();
})();