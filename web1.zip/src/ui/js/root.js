var $root = {
    jsonEditor: null,
    rawEditor: null,
    gridViewer: null,
    lazyLoader: null,
    toast: null,
    state: null,
    util: null,
    constants: null,
    site: null
};