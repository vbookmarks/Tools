//Base plugins
//npm install gulp gulp-newer gulp-concat merge-stream --save-dev

// CSS processing
//npm install gulp-sass gulp-clean-css  gulp-sass-themes-combiner --save-dev

// JavsScript processing
//npm install gulp-deporder gulp-uglify gulp-javascript-obfuscator --save-dev
var baseSrc = 'src/';
var src = baseSrc + 'ui/';
var api = 'api/';
var router = 'router/';
var srcAssets = src + 'assets/'
var baseDest = 'dest/';
var dest = baseDest + 'ui/';
var images = 'images/';
var fonts = 'fonts/'
var webfonts = 'webfonts/'
var js = 'js/';
var libs = 'libs/';
var theme = 'theme/';
var css = 'css/';
var scss = 'scss/';
var ejs = 'ejs/';
var all = '**/*';

//base
var gulp = require('gulp');
var mergeStream = require('merge-stream');
var streamqueue = require('streamqueue');
var filesChanged = require('gulp-newer');
var combineFiles = require('gulp-concat');
var orderFiles = require('gulp-order');
//css processing
var sassToCss = require('gulp-sass');
var cssMinify = require('gulp-clean-css');
var themesCombiner = require('gulp-sass-themes-combiner');

//js processing
var jsDependencyOrder = require('gulp-deporder');
var jsMinify = require('gulp-uglify');
var jsObfuscate = require('gulp-javascript-obfuscator');

//nodejs files
gulp.task('server', function () {
    var serverApi = gulp.src(baseSrc + api + all).pipe(gulp.dest(baseDest + api));
    var serverRouter = gulp.src(baseSrc + router + all).pipe(gulp.dest(baseDest + router));
    var serverjs = gulp.src(baseSrc + 'server.js').pipe(gulp.dest(baseDest));
    var packagejson = gulp.src(baseSrc + 'package.json').pipe(gulp.dest(baseDest));

    return mergeStream(serverApi, serverjs, serverRouter, packagejson);
});

//images
gulp.task('images', function () {
    var from = srcAssets + images + all;
    var to = dest + images;
    return gulp.src(from).pipe(gulp.dest(to));
});

//fonts
gulp.task('fonts', function () {
    var _fonts = gulp.src(srcAssets + fonts + all).pipe(gulp.dest(dest + fonts));
    var _webfonts = gulp.src(srcAssets + webfonts + all).pipe(gulp.dest(dest + webfonts));
    return mergeStream(_fonts, _webfonts);
});

//libs-css
gulp.task('libs-css', function () {
    var stCss = gulp.src(srcAssets + libs + css + all).pipe(combineFiles('vendor.css')).pipe(gulp.dest(dest + css));
    var stTheme = gulp.src(srcAssets + libs + theme + all).pipe(gulp.dest(dest + css));
    return mergeStream(stCss, stTheme);
});

//scss
gulp.task('scss', function () {

    var stScss = gulp.src(src + scss + all)
        //.pipe(filesChanged(to))
        .pipe(sassToCss().on('error', sassToCss.logError))
        .pipe(cssMinify())
        .pipe(combineFiles('bundle.css'))
        .pipe(gulp.dest(dest + css));

    var combInstance = themesCombiner(src + theme + 'themes/_*.scss');

    var stTheme = gulp.src(src + 'theme/**/*.scss')
        .pipe(combInstance.init())
        .pipe(sassToCss.sync().on("error", sassToCss.logError))
        .pipe(combInstance.combine('theme.override'))
        .pipe(gulp.dest(dest + css));

    return mergeStream(stScss, stTheme);
});

//JS
gulp.task('js', function () {
    var fromAssests = srcAssets + libs + js + all;
    var from = src + js + all;
    var to = dest + js;

    var assetsJs = gulp.src(fromAssests).pipe(jsDependencyOrder());
    var copyrightNote = gulp.src(src + js + 'copyright.txt');
    var bundleJs = gulp.src(from).pipe(jsDependencyOrder())
        .pipe(jsMinify())
        .pipe(jsObfuscate())
        ;

    return streamqueue(
        { objectMode: true },
        assetsJs,
        copyrightNote,
        bundleJs
    ).pipe(combineFiles('bundle.js')).pipe(gulp.dest(to));
});

//ejs
gulp.task('ejs', function () {
    var from = src + ejs + all;
    var to = dest + ejs;
    return gulp.src(from).pipe(gulp.dest(to));
});

// run all tasks
gulp.task('run', gulp.parallel('server', 'images', 'fonts', 'libs-css', 'scss', 'js', 'ejs'));

//watch for changes
gulp.task('watch', function () {
    var fromEJS = src + ejs + all;
    var fromJS = src + js + all;
    var fromScss = src + scss + all;
    var fromTheme = src + theme + all;
    var fromApi = baseSrc + api + all;
    var fromRouter = baseSrc + router + all;

    gulp.watch(fromTheme, gulp.series('scss'));
    gulp.watch(fromScss, gulp.series('scss'));
    gulp.watch(fromJS, gulp.series('js'));
    gulp.watch(fromEJS, gulp.series('ejs'));
    gulp.watch(fromApi, gulp.series('server'));
    gulp.watch(fromRouter, gulp.series('server'));
});

//default task
gulp.task('default', gulp.series('run', 'watch'));